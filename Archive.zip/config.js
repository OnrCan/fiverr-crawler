const proxy = {
	credentials: {
		username: "ankushankush",
		password: "YiY2W!eqzTePu3"
	},
	port: "12345",
	ipPool: [
		"130.185.156.71",
		"196.245.232.181",
		"172.245.58.3",
		"172.245.58.7",
		"130.185.156.103",
		"171.22.254.162",
		"171.22.254.213",
		"171.22.254.248",
		"172.245.58.20"
	]
}

module.exports = { proxy: proxy };