#1
`nvm use`

#2
`npm install`

#3
`node index.js`