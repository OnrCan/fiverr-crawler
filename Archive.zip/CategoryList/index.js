const categoryList = require('./category-list');

module.exports = categoryList;